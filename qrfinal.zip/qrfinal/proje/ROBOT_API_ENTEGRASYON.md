# Kapı Durumu API'si — Robot Entegrasyon Rehberi

Sunucu adresi: `http://<SUNUCU_IP>:5000` (aynı ağdaysa örn. `http://172.16.3.243:5000`)

## Adım 1 — Robot bir kabine vardığında: hangi otomasyonu izleyeceğini bildir

```
POST /api/set_target
Content-Type: application/json

{"name": "Y Otomasyonu"}
```

**Başarılı cevap (200):**
```json
{
  "success": true,
  "id": "oto_y",
  "data": {
    "name": "Y Otomasyonu",
    "kapi_tipi": "Sabit + Dışa Katlanır Kapak",
    "robot_mesafesi_m": 0.9,
    "mesafe_toleransi": 0.08,
    "referans_alindi": true,
    "qr_cifti": "https://a.com | https://b.com"
  }
}
```

**Otomasyon bulunamazsa (404):**
```json
{"success": false, "error": "Otomasyon bulunamadi (id veya name eslesmedi)"}
```
Bu durumda gönderilen isim Otomasyon Ekranı'ndaki kayıtlı isimle birebir eşleşmiyordur (büyük/küçük harf ve boşluklara dikkat).

## Adım 2 — Durumu sorgula (istediğin sıklıkta tekrar çağır)

```
GET /api/state
```

**Cevap:**
```json
{
  "status": "KAPALI",
  "is_open": false,
  "automation_id": "Y Otomasyonu",
  "cabinet_type": "Sabit + Dışa Katlanır Kapak",
  "qr_count": 2,
  "last_update": 1785348198.32
}
```

**`is_open` alanına bak, karar vermek için bu yeterli:**
- `true` → kapı açık
- `false` → kapı kapalı
- `null` → henüz belirsiz (referans alınmamış, otomasyon seçili kapıyla eşleşmiyor, sistem durdurulmuş vb. — sebebini `status` metninden okuyabilirsin, ör. `"REFERANS YOK"`, `"OTOMASYON UYUSMUYOR"`, `"DURDURULDU"`)

## Python örneği

```python
import requests
import time

BASE_URL = "http://172.16.3.243:5000"

def hedefi_ayarla(otomasyon_adi):
    r = requests.post(f"{BASE_URL}/api/set_target", json={"name": otomasyon_adi})
    r.raise_for_status()
    return r.json()

def durumu_al():
    r = requests.get(f"{BASE_URL}/api/state")
    r.raise_for_status()
    return r.json()

# Robot kabine vardığında bir kere çağır
hedefi_ayarla("Y Otomasyonu")

# Sonra istediğin sıklıkta durumu sorgula
while True:
    state = durumu_al()
    if state["is_open"] is True:
        print("Kapı açık:", state["status"])
    elif state["is_open"] is False:
        print("Kapı kapalı")
    else:
        print("Belirsiz durum:", state["status"])
    time.sleep(1)
```

## Hızlı test (kod yazmadan, terminalden)

```bash
curl -X POST http://172.16.3.243:5000/api/set_target -H "Content-Type: application/json" -d "{\"name\": \"Y Otomasyonu\"}"
curl http://172.16.3.243:5000/api/state
```
