document.addEventListener('DOMContentLoaded', () => {

    // --- DOM ELEMENTS (ADMIN) ---
    const formAdd = document.getElementById('form-add-automation');
    const tableBody = document.getElementById('table-body');
    const searchInput = document.getElementById('search-input');
    
    // Popups
    const popupOverlay = document.getElementById('popup-overlay');
    const popupMsg = document.getElementById('popup-msg');
    const btnPopupOk = document.getElementById('btn-popup-ok');
    
    const deleteOverlay = document.getElementById('delete-overlay');
    const btnDeleteCancel = document.getElementById('btn-delete-cancel');
    const btnDeleteConfirm = document.getElementById('btn-delete-confirm');

    let automationsList = {};
    let activeAutoId = null;
    let deleteConfirmId = null;

    // --- POPUP UTILS ---
    function showAlert(msg) {
        popupMsg.textContent = msg;
        popupOverlay.classList.remove('hidden');
    }
    
    btnPopupOk.addEventListener('click', () => {
        popupOverlay.classList.add('hidden');
    });

    btnDeleteCancel.addEventListener('click', () => {
        deleteOverlay.classList.add('hidden');
        deleteConfirmId = null;
    });

    btnDeleteConfirm.addEventListener('click', () => {
        if (deleteConfirmId) {
            fetch(`/api/automations/${deleteConfirmId}`, { method: 'DELETE' })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        delete automationsList[deleteConfirmId];
                        if (activeAutoId === deleteConfirmId) activeAutoId = null;
                        renderTable();
                    }
                });
        }
        deleteOverlay.classList.add('hidden');
    });

    // --- FETCH & RENDER TABLE ---
    function fetchAutomations() {
        fetch('/api/automations')
            .then(res => res.json())
            .then(data => {
                automationsList = data;
                renderTable();
            });
    }

    function renderTable() {
        const query = searchInput.value.toLowerCase();
        tableBody.innerHTML = '';
        
        let hasRows = false;
        
        for (const [id, auto] of Object.entries(automationsList)) {
            if (!auto.name.toLowerCase().includes(query)) continue;
            hasRows = true;

            const tr = document.createElement('tr');
            
            // SEÇ (Radio)
            const isChecked = activeAutoId === id ? 'checked' : '';
            const tdSelect = `<td style="text-align: center;"><input type="radio" name="auto-select" class="radio-select" value="${id}" ${isChecked}></td>`;
            
            // NAME
            const tdName = `<td style="font-weight: 800; color: rgb(0, 45, 122);">${auto.name}</td>`;
            
            // TYPE
            const tdType = `<td>${auto.kapi_tipi}</td>`;

            // ROBOT MESAFESİ
            const tip = KAPI_TIPLERI[auto.kapi_tipi];
            const mesafeAsimi = tip && auto.robot_mesafesi_m > tip.maksMesafe;
            const tdMesafe = `
                <td style="text-align: center;">
                    <input type="number" step="0.1" class="table-input" style="width: 65px;" value="${auto.robot_mesafesi_m}" data-id="${id}" data-field="robot_mesafesi_m">
                    ${mesafeAsimi ? `<div style="color:#ef4444; font-size:0.75rem; margin-top:3px;">⚠ &gt;${tip.maksMesafe}m</div>` : ''}
                </td>`;

            // TOLERANCES
            const tdTols = `
                <td style="text-align: center;">
                    <div style="display:inline-flex; align-items:center; gap:5px;">
                        <input type="number" step="0.1" class="table-input" value="${(auto.mesafe_toleransi * 100).toFixed(2)}" data-id="${id}" data-field="mesafe_toleransi"> %
                    </div>
                </td>`;

            // REFERANS DURUMU
            const tdReferans = `
                <td style="text-align: center; font-weight: 700; color: ${auto.referans_alindi ? '#10b981' : '#ef4444'};">
                    ${auto.referans_alindi ? '✓ Alındı' : '✗ Alınmadı'}
                </td>`;

            // DELETE
            const tdDelete = `
                <td style="text-align: center;">
                    <button class="btn-delete" data-id="${id}">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                            <polyline points="3 6 5 6 21 6"></polyline>
                            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                        </svg>
                    </button>
                </td>`;

            tr.innerHTML = tdSelect + tdName + tdType + tdMesafe + tdTols + tdReferans + tdDelete;
            tableBody.appendChild(tr);
        }

        if (!hasRows) {
            tableBody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:30px; color:#94a3b8;">Aranan kriterlere uygun otomasyon bulunamadı.</td></tr>`;
        }

        attachTableEvents();
    }

    function attachTableEvents() {
        // Radio Buttons (Select Target)
        document.querySelectorAll('.radio-select').forEach(radio => {
            radio.addEventListener('change', (e) => {
                const selectedId = e.target.value;
                activeAutoId = selectedId;

                const targetingOverlay = document.getElementById('targeting-overlay');
                const targetingText = document.getElementById('targeting-text');
                const autoName = automationsList[selectedId] ? automationsList[selectedId].name : 'seçilen otomasyon';
                if (targetingOverlay) {
                    if (targetingText) targetingText.textContent = `Robot "${autoName}" hedefine yönlendiriliyor...`;
                    targetingOverlay.classList.remove('hidden');
                }

                fetch('/api/set_target', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({id: selectedId})
                }).then(res => res.json()).then(data => {
                    if (data.success) {
                        // Yönlendirme animasyonu bir an görünsün, sonra Ana Ekran'a gec
                        setTimeout(() => { window.location.href = '/'; }, 900);
                    } else if (targetingOverlay) {
                        targetingOverlay.classList.add('hidden');
                        showAlert('Otomasyon hedeflenemedi: ' + (data.error || 'bilinmeyen hata'));
                    }
                });
            });
        });

        // Inputs (Update value on change)
        document.querySelectorAll('.table-input').forEach(input => {
            input.addEventListener('change', (e) => {
                const id = e.target.getAttribute('data-id');
                const field = e.target.getAttribute('data-field');
                const val = parseFloat(e.target.value);
                
                const payload = {};
                payload[field] = field === "mesafe_toleransi" ? val / 100 : val;

                fetch(`/api/automations/${id}`, {
                    method: 'PUT',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify(payload)
                }).then(res => res.json()).then(data => {
                    if(data.success) {
                        if (field === "robot_mesafesi_m") automationsList[id].robot_mesafesi_m = val;
                        else if (field === "mesafe_toleransi") automationsList[id].mesafe_toleransi = val / 100;
                        renderTable();
                    }
                });
            });
        });

        // Delete Buttons
        document.querySelectorAll('.btn-delete').forEach(btn => {
            btn.addEventListener('click', (e) => {
                deleteConfirmId = e.currentTarget.getAttribute('data-id');
                deleteOverlay.classList.remove('hidden');
            });
        });

    }

    if (searchInput) {
        searchInput.addEventListener('input', renderTable);
    }

    // --- ADD AUTOMATION ---
    if (formAdd) {
        formAdd.addEventListener('submit', (e) => {
            e.preventDefault();
            const name = document.getElementById('new-name').value.trim();
            if (!name) return;

            // Check exists
            const exists = Object.values(automationsList).some(a => a.name.toLowerCase() === name.toLowerCase());
            if (exists) {
                showAlert(`"${name}" isimli otomasyon sistemde zaten kayıtlı.`);
                return;
            }

            const payload = {
                name: name,
                kapi_tipi: document.getElementById('new-type').value,
                robot_mesafesi_m: document.getElementById('new-distance').value,
                mesafe_toleransi: parseFloat(document.getElementById('new-dist-tol').value) / 100
            };

            fetch('/api/automations', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(payload)
            })
            .then(res => res.json())
            .then(response => {
                if (response.success) {
                    automationsList[response.id] = response.data;
                    renderTable();
                    formAdd.reset();
                    document.getElementById('new-distance').value = "1.2";
                    document.getElementById('new-dist-tol').value = "5";
                    document.getElementById('new-distance').dispatchEvent(new Event('input'));
                }
            });
        });
    }

    // --- LIVE CONTROLS (MAIN SCREEN) ---
    const liveDistTol = document.getElementById('live-dist-tol');
    const btnToggleAnalysis = document.getElementById('btn-toggle-analysis');
    let isAnalyzing = true;
    let openAlertSeconds = 30;

    function updateLiveControlsFromConfig(config) {
        if(liveDistTol) liveDistTol.value = (config.DISTANCE_TOLERANCE * 100).toFixed(2);
        isAnalyzing = config.IS_ACTIVE;
        if (config.OPEN_ALERT_SECONDS) openAlertSeconds = config.OPEN_ALERT_SECONDS;
        updateToggleBtnState();
    }

    // --- KAMERA BAGLANTI DURUMU ---
    const cameraStatusText = document.getElementById('camera-status-text');
    const cameraLiveIndicator = document.getElementById('camera-live-indicator');
    const btnCameraReconnect = document.getElementById('btn-camera-reconnect');

    if (btnCameraReconnect) {
        btnCameraReconnect.addEventListener('click', () => {
            fetch('/api/camera/reconnect', { method: 'POST' });
        });
    }

    function updateCameraStatus(connected) {
        if (!cameraStatusText || !cameraLiveIndicator) return;
        cameraLiveIndicator.classList.remove('online', 'offline');
        if (connected) {
            cameraStatusText.textContent = "Bağlı";
            cameraLiveIndicator.classList.add('online');
        } else {
            cameraStatusText.textContent = "Bağlantı Yok";
            cameraLiveIndicator.classList.add('offline');
        }
    }

    // --- DURUM SÜRESİ (kapı ne kadardır bu durumda) ---
    const statusDurationEl = document.getElementById('status-duration');

    function updateStatusDuration(isOpen, statusSince) {
        if (!statusDurationEl) return;
        const elapsed = Math.max(0, Math.round(Date.now() / 1000 - statusSince));
        if (isOpen === true) {
            statusDurationEl.textContent = `${elapsed} saniyedir AÇIK`;
            liveStatusEl.classList.toggle('critical', elapsed > openAlertSeconds);
        } else {
            statusDurationEl.textContent = "Anlık Sensör Analizi";
            liveStatusEl.classList.remove('critical');
        }
    }

    // --- SON OLAYLAR (durum gecmisi) ---
    const eventHistoryListEl = document.getElementById('event-history-list');
    let lastHistoryStatus = null;
    let lastHistoryTimestamps = [];

    function formatTime(ts) {
        const d = new Date(ts * 1000);
        return d.toLocaleTimeString('tr-TR', {hour: '2-digit', minute: '2-digit', second: '2-digit'});
    }

    function fetchHistory() {
        if (!eventHistoryListEl) return;
        fetch('/api/history')
            .then(res => res.json())
            .then(events => {
                if (!events.length) {
                    eventHistoryListEl.innerHTML = '<li class="event-history-empty">Henüz bir durum değişikliği yok.</li>';
                    lastHistoryTimestamps = [];
                    return;
                }

                const newTimestamps = events.map(ev => ev.timestamp);
                const unchanged = newTimestamps.length === lastHistoryTimestamps.length &&
                    newTimestamps.every((t, i) => t === lastHistoryTimestamps[i]);
                if (unchanged) return; // icerik ayni, yeniden cizip kaydirmayi bozma

                // Kullanici eski kayitlari okumak icin asagi kaydirmissa, o konumu koru
                const prevScrollTop = eventHistoryListEl.scrollTop;
                const prevScrollHeight = eventHistoryListEl.scrollHeight;

                eventHistoryListEl.innerHTML = events.map(ev =>
                    `<li><span class="event-history-time">${formatTime(ev.timestamp)}</span><span class="event-history-status">${ev.status}</span></li>`
                ).join('');
                lastHistoryTimestamps = newTimestamps;

                if (prevScrollTop > 0) {
                    eventHistoryListEl.scrollTop = prevScrollTop + (eventHistoryListEl.scrollHeight - prevScrollHeight);
                }
            })
            .catch(() => {});
    }

    function updateToggleBtnState() {
        if (!btnToggleAnalysis) return;
        
        const standbyOverlay = document.getElementById('standby-overlay');
        const videoStream = document.getElementById('video-stream');
        
        if (isAnalyzing) {
            btnToggleAnalysis.textContent = "DENETİMİ BİTİR";
            if (standbyOverlay) standbyOverlay.classList.add('hidden');
            if (videoStream) videoStream.style.opacity = '1';
        } else {
            btnToggleAnalysis.textContent = "DENETİMİ BAŞLAT";
            if (standbyOverlay) standbyOverlay.classList.remove('hidden');
            if (videoStream) videoStream.style.opacity = '0.3'; // Kamarayı karart
        }
    }

    if (btnToggleAnalysis) {
        btnToggleAnalysis.addEventListener('click', () => {
            isAnalyzing = !isAnalyzing;
            updateToggleBtnState();
            fetch('/api/config', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({IS_ACTIVE: isAnalyzing})
            });
        });
    }

    // --- REFERANS AL (manuel, tek seferlik yakalama) ---
    const btnCaptureReference = document.getElementById('btn-capture-reference');
    const referenceStatusEl = document.getElementById('reference-status');

    if (btnCaptureReference) {
        btnCaptureReference.addEventListener('click', () => {
            fetch('/api/capture_reference', { method: 'POST' })
                .then(res => res.json())
                .then(() => {
                    if (referenceStatusEl) {
                        referenceStatusEl.textContent = "Referans yakalanıyor, kapıyı kapalı ve sabit tutun...";
                    }
                });
        });
    }

    if (liveDistTol) {
        liveDistTol.addEventListener('change', () => {
            const fraction = parseFloat(liveDistTol.value) / 100;

            fetch('/api/config', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    DISTANCE_TOLERANCE: fraction
                })
            });

            if (activeAutoId) {
                if (automationsList[activeAutoId]) {
                    automationsList[activeAutoId].mesafe_toleransi = fraction;
                }

                fetch(`/api/automations/${activeAutoId}`, {
                    method: 'PUT',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        mesafe_toleransi: fraction
                    })
                });
            }
        });
    }

    // --- CAMERA TAB METRICS (Poll state) ---
    const liveStatusEl = document.getElementById('live-status');
    const autoIdEl = document.getElementById('auto-id');
    const qrCountEl = document.getElementById('qr-count');
    const qrCountWarningEl = document.getElementById('qr-count-warning');

    if (liveStatusEl) {
        setInterval(() => {
            fetch('/api/state')
                .then(response => response.json())
                .then(data => {
                    liveStatusEl.textContent = data.status;
                    autoIdEl.textContent = data.automation_id;
                    qrCountEl.textContent = data.qr_count;
                    if (qrCountWarningEl) qrCountWarningEl.classList.toggle('hidden', data.qr_count >= 2);

                    updateCameraStatus(data.camera_connected);
                    updateStatusDuration(data.is_open, data.status_since);

                    if (data.status !== lastHistoryStatus) {
                        lastHistoryStatus = data.status;
                        fetchHistory();
                    }

                    liveStatusEl.className = 'status-text';
                    if (data.status.startsWith("KAPALI")) {
                        liveStatusEl.classList.add('safe');
                    } else if (data.status.startsWith("ACIK (Eksik")) {
                        liveStatusEl.classList.add('warning');
                    } else if (data.status.startsWith("ACIK")) {
                        liveStatusEl.classList.add('danger');
                    } else if (data.status.startsWith("REFERANS ALINIYOR")) {
                        liveStatusEl.classList.add('warning');
                    } else if (data.status.startsWith("OTOMASYON UYUSMUYOR")) {
                        liveStatusEl.classList.add('warning');
                    } else {
                        liveStatusEl.classList.add('unknown');
                    }

                    if (referenceStatusEl) {
                        if (data.status.startsWith("REFERANS ALINIYOR")) {
                            referenceStatusEl.textContent = data.status;
                        } else if (data.status.startsWith("KAPALI (Referans Kaydedildi")) {
                            const tolMatch = data.status.match(/Onerilen Tolerans %([\d.]+)/);
                            const qualityMatch = data.status.match(/Kalite: (\w+)/);
                            const qualityText = qualityMatch ? ` Referans kalitesi: ${qualityMatch[1]}.` : '';
                            referenceStatusEl.textContent = tolMatch
                                ? `Referans kaydedildi. Ölçülen gürültüye göre tolerans %${tolMatch[1]} olarak ayarlandı, dilersen elle değiştirebilirsin.${qualityText}`
                                : "Referans kaydedildi. Toleransları artık canlı ayarlayabilirsiniz.";
                            fetch('/api/config').then(res => res.json()).then(config => updateLiveControlsFromConfig(config));
                        } else if (data.status.startsWith("REFERANS YOK")) {
                            referenceStatusEl.textContent = "Bu kapı için referans yok. Kapıyı kapalı görürken 'Referans Al' butonuna basın.";
                        } else if (data.status.startsWith("REFERANS HATASI")) {
                            referenceStatusEl.textContent = "Yakalama sırasında farklı bir QR çifti görüldü. Tekrar deneyin.";
                        } else if (data.status.startsWith("OTOMASYON UYUSMUYOR")) {
                            referenceStatusEl.textContent = "Seçili otomasyon bu kapının QR'larıyla eşleşmiyor. Doğru otomasyonu seçtiğinizden emin olun.";
                        }
                    }
                })
                .catch(err => {});
        }, 500);
    }

    // Initial Load
    if (tableBody) {
        fetchAutomations();
    }
    
    fetch('/api/config').then(res => res.json()).then(config => {
        updateLiveControlsFromConfig(config);
        if (config.ACTIVE_AUTO_ID) {
            activeAutoId = config.ACTIVE_AUTO_ID;
        }
    });

    fetchHistory();
});
