import os
import json

db_path = os.path.join(os.path.dirname(__file__), 'automations_db.json')

def load_db():
    if os.path.exists(db_path):
        with open(db_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {}

def save_db(data):
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    with open(db_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

automations_db = load_db()
