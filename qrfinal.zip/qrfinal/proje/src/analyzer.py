import os
import math
import collections
import numpy as np
import json
from .config import current_config, system_state
from .db_manager import automations_db, save_db
import time

class DoorStatusAnalyzer:
    def __init__(self):
        self.history = collections.deque(maxlen=15)
        self.baselines_file = os.path.join(os.path.dirname(__file__), 'baselines.json')
        os.makedirs(os.path.dirname(self.baselines_file), exist_ok=True)
        self.baselines = self._load_baselines()
        
        # Hysteresis Durumu
        self.current_solid_status = "BILINMIYOR"
        self.status_counter = 0
        self.REQUIRED_CONSECUTIVE_FRAMES = 5  # Durum değiştirmek için gereken peş peşe aynı sonuç sayısı

        # --- REFERANS YAKALAMA (artık OTOMATİK DEĞİL, operatör tetikler) ---
        # Kamera sabit ve titreşimsiz kabul edildiği için, operatör "Referans Al"
        # dediğinde 20 karelik ortalama alınır (gürültüye karşı sağlamlık için).
        # Bu değerler sadece "kapalı hali budur" bilgisidir; tolerans hesaplamaz.
        self.REQUIRED_CALIBRATION_FRAMES = 20
        self.calibration_buffer = []
        self.capturing_reference = False   # Operatör butona basınca True olur
        self.capture_cabinet_key = None    # Yakalama sırasında hangi kapı görülüyor

    def _load_baselines(self):
        if os.path.exists(self.baselines_file):
            try:
                with open(self.baselines_file, 'r') as f:
                    return json.load(f)
            except: pass
        return {}

    def _save_baseline(self, key, data):
        self.baselines[key] = data
        try:
            with open(self.baselines_file, 'w') as f:
                json.dump(self.baselines, f, indent=4)
        except: pass

    def _calculate_center(self, points):
        return np.mean(points[:, 0]), np.mean(points[:, 1])

    def _calculate_width(self, points):
        return (np.linalg.norm(points[0]-points[1]) + np.linalg.norm(points[2]-points[3])) / 2.0

    def _calculate_distance(self, c1, c2):
        return math.sqrt((c1[0]-c2[0])**2 + (c1[1]-c2[1])**2)

    def _filter_reflections(self, qr_list):
        if len(qr_list) <= 2:
            return qr_list
        qr_list.sort(key=lambda qr: self._calculate_width(qr['points']), reverse=True)
        return qr_list[:2]

    def _update_hysteresis(self, new_raw_status):
        # Eğer okunamadı veya eksik QR ise anında tepki verme, mevcut durumu koru ama sayacı sıfırla
        if "BILINMIYOR" in new_raw_status or "Eksik" in new_raw_status:
            # Sadece çok uzun süre QR görülmezse durumu ACIK(Eksik) yap
            self.history.append(new_raw_status)
            c = collections.Counter(self.history)
            if c[new_raw_status] >= 10:
                self.current_solid_status = new_raw_status
            return self.current_solid_status

        # Durum değişimi kontrolü
        if new_raw_status == self.current_solid_status:
            self.status_counter = 0
            self.history.append(new_raw_status)
        else:
            self.status_counter += 1
            if self.status_counter >= self.REQUIRED_CONSECUTIVE_FRAMES:
                self.current_solid_status = new_raw_status
                self.status_counter = 0
                self.history.clear()
        
        return self.current_solid_status

    def start_reference_capture(self):
        """Operatör 'Referans Al (Kapalı)' butonuna bastığında çağrılır.
        Otomatik/gizli öğrenme yoktur; bu, operatörün bilinçli olarak tetiklediği
        tek seferlik bir aksiyondur. Kamera sabit varsayıldığından 20 karelik
        ortalama sadece küçük gürültüye karşı sağlamlık sağlar."""
        self.calibration_buffer = []
        self.capturing_reference = True
        self.capture_cabinet_key = None

    def cancel_reference_capture(self):
        self.calibration_buffer = []
        self.capturing_reference = False
        self.capture_cabinet_key = None

    def analyze(self, qr_list):
        if not current_config.IS_ACTIVE:
            return "DURDURULDU"

        # Referans yakalama operatör tetikli, zaten 20 karelik ortalamayla
        # kendi içinde sağlamlaştırılmış bir süreç - kararsız AÇIK/KAPALI
        # gürültüsüne karşı tasarlanmış histerezis buraya uygulanırsa her
        # kare farklı bir "%N" string'i üretmesi yüzünden yüzde göstergesi
        # gecikmeli/atlamalı ilerliyordu. Bu yüzden yakalama sürerken
        # histerezis atlanır, sonuç doğrudan yansıtılır.
        was_capturing = self.capturing_reference
        raw_status = self._get_raw_status(qr_list)
        if was_capturing:
            self.current_solid_status = raw_status
            self.status_counter = 0
            self.history.clear()
            return raw_status

        return self._update_hysteresis(raw_status)

    def _get_raw_status(self, qr_list):
        filtered_qrs = self._filter_reflections(qr_list)
        
        if len(filtered_qrs) < 2: return "ACIK (Eksik QR)"
        if len(filtered_qrs) > 2: return "BILINMIYOR (Cok fazla QR)"

        filtered_qrs.sort(key=lambda qr: self._calculate_center(qr['points'])[0])

        qr1, qr2 = filtered_qrs[0], filtered_qrs[1]
        data1, data2 = qr1['data'], qr2['data']
        
        if not data1 or not data2: return "BILINMIYOR (QR Okunamadi)"

        pts1, pts2 = qr1['points'], qr2['points']
        center1 = self._calculate_center(pts1)
        center2 = self._calculate_center(pts2)
        dist = self._calculate_distance(center1, center2)
        avg_w = (self._calculate_width(pts1) + self._calculate_width(pts2)) / 2.0
        
        cur_dist_ratio = dist / avg_w if avg_w > 0 else 0

        cabinet_key = f"{data1} | {data2}"

        # --- MANUEL REFERANS YAKALAMA (operatör "Referans Al" ile tetikler) ---
        # Otomatik/gizli öğrenme YOK. Operatör kapıyı kapalı gördüğünde butona basar,
        # sistem o kapı için 20 kare toplayıp ortalamasını referans olarak kaydeder.
        # Burada tolerans HESAPLANMAZ - sadece "kapalı hali" geometrisi kaydedilir.
        if self.capturing_reference:
            if self.capture_cabinet_key is None:
                self.capture_cabinet_key = cabinet_key

            if cabinet_key != self.capture_cabinet_key:
                return "REFERANS HATASI (Beklenmeyen QR cifti)"

            self.calibration_buffer.append({
                "dist": cur_dist_ratio,
                "w1": self._calculate_width(pts1),
                "w2": self._calculate_width(pts2)
            })

            if len(self.calibration_buffer) < self.REQUIRED_CALIBRATION_FRAMES:
                pct = int((len(self.calibration_buffer) / self.REQUIRED_CALIBRATION_FRAMES) * 100)
                return f"REFERANS ALINIYOR... %{pct}"

            # 20 kare toplandı: ortalamasını al ve KALICI referans olarak kaydet.
            dists = [x["dist"] for x in self.calibration_buffer]
            w1s = [x["w1"] for x in self.calibration_buffer]
            w2s = [x["w2"] for x in self.calibration_buffer]

            avg_dist = float(np.mean(dists))
            std_dist = float(np.std(dists))

            self._save_baseline(cabinet_key, {
                "distance_ratio": avg_dist,
                "qr1_width": float(np.mean(w1s)),
                "qr2_width": float(np.mean(w2s)),
            })

            # Tolerans, 20 karelik referansta ÖLÇÜLEN gürültüye göre öneriliyor
            # (sapma ne kadar büyükse, o kapı/mesafe için tolerans o kadar geniş olmalı).
            # Bu değer donmuş DEĞİL: normal analizde her kare current_config.DISTANCE_TOLERANCE
            # okunuyor, operatör istediği an elle değiştirebiliyor.
            MIN_TOLERANCE = 0.02
            noise_ratio = (std_dist / avg_dist) if avg_dist > 0 else 0.0
            suggested_tol = max(MIN_TOLERANCE, noise_ratio * 3.0)
            current_config.DISTANCE_TOLERANCE = suggested_tol

            if noise_ratio < 0.02:
                quality = "Iyi"
            elif noise_ratio < 0.05:
                quality = "Orta"
            else:
                quality = "Gurultulu"

            active_auto_id = current_config.ACTIVE_AUTO_ID
            if active_auto_id and active_auto_id in automations_db:
                automations_db[active_auto_id]["referans_alindi"] = True
                automations_db[active_auto_id]["qr_cifti"] = cabinet_key
                automations_db[active_auto_id]["mesafe_toleransi"] = suggested_tol
                save_db(automations_db)

            self.calibration_buffer = []
            self.capturing_reference = False
            self.capture_cabinet_key = None
            return f"KAPALI (Referans Kaydedildi, Onerilen Tolerans %{suggested_tol * 100:.1f}, Kalite: {quality})"

        # --- OTOMASYON <-> QR EŞLEŞME KONTROLÜ ---
        # Seçili otomasyonun referansı hangi QR çiftine kilitliyse (ilk "Referans Al" anında
        # kaydedilir), kameranın o an gördüğü QR çifti bununla uyuşmuyorsa yanlış otomasyon/
        # yanlış kapı ihtimaline karşı analiz yapılmaz, açıkça uyarılır.
        active_auto_id = current_config.ACTIVE_AUTO_ID
        if active_auto_id and active_auto_id in automations_db:
            bound_key = automations_db[active_auto_id].get("qr_cifti")
            if bound_key and bound_key != cabinet_key:
                return "OTOMASYON UYUSMUYOR"

        # --- Referans hiç alınmamışsa ---
        if cabinet_key not in self.baselines or "qr1_width" not in self.baselines[cabinet_key]:
            return "REFERANS YOK"

        # --- NORMAL ANALİZ ---
        # Referans (kapalı hali) SABİTTİR - sadece "Referans Al" ile değişir.
        # Toleranslar ise HER KAREDE arayüzdeki canlı değerden okunur; operatör
        # slider'ı oynattığı an bir sonraki karede etkisi görülür.
        base = self.baselines[cabinet_key]

        dist_tol = current_config.DISTANCE_TOLERANCE

        # Mesafe İhlali - tek karar kriteri
        base_dist_ratio = base["distance_ratio"] or 1
        ratio_diff = abs(cur_dist_ratio - base_dist_ratio) / base_dist_ratio
        distance_violated = ratio_diff > dist_tol

        if distance_violated:
            return "ACIK"

        return "KAPALI"
