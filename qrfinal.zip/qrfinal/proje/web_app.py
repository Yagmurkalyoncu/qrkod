import cv2
import sys
import math
import collections
import numpy as np
import json
import os
import logging
import threading
import time
import uuid
from flask import Flask, render_template, Response, jsonify, request

from src.config import current_config, system_state
from src.logger import logger
from src.db_manager import automations_db, save_db
from src.qr_detector import QRScanner
from src.analyzer import DoorStatusAnalyzer

# ---------------- KAMERA YÖNETİCİSİ ---------------- #
class CameraManager:
    """Kamerayı güvenli şekilde arka planda okuyan yönetici sınıf.
    Windows DirectShow thread kilitlenmelerini önler ve her zaman en güncel kareyi verir."""
    
    def __init__(self):
        self._cap = None
        self._lock = threading.Lock()
        self.frame = None
        self.is_running = False
        self.thread = None
        self.last_frame_time = 0

    @property
    def is_connected(self):
        return (time.time() - self.last_frame_time) < 3.0

    def start(self):
        with self._lock:
            if self.is_running:
                return True
            self.is_running = True
            self.thread = threading.Thread(target=self._update, daemon=True)
            self.thread.start()
            return True

    def _update(self):
        while self.is_running:
            if self._cap is None or not self._cap.isOpened():
                # Webcam index'i (int) için DSHOW backend zorunlu: varsayılan backend
                # arka plan thread'inde açılışı 8+ saniyeye kadar yavaşlatıyor/kilitleyebiliyor.
                if isinstance(current_config.CAMERA_SOURCE, int):
                    self._cap = cv2.VideoCapture(current_config.CAMERA_SOURCE, cv2.CAP_DSHOW)
                else:
                    self._cap = cv2.VideoCapture(current_config.CAMERA_SOURCE)
                if self._cap.isOpened():
                    # Çözünürlük değiştirme (1280x720 vs) Windows kameralarını kilitlediği için tamamen kaldırıldı. 
                    # Kamera varsayılan çözünürlüğüyle (genelde 640x480) güvenli modda çalışacak.
                    logger.info("Kamera basariyla acildi.")
                else:
                    self._cap = None
                    time.sleep(1.0)
                    continue

            success, frame = self._cap.read()
            if success:
                self.frame = frame
                self.last_frame_time = time.time()
            else:
                self.release()
                time.sleep(0.5)

    def read(self):
        return self.frame is not None, self.frame
    
    def release(self):
        if self._cap is not None:
            self._cap.release()
            self._cap = None

# ---------------- FLASK APP ---------------- #
app = Flask(__name__)
scanner = QRScanner()
analyzer = DoorStatusAnalyzer()
camera_manager = CameraManager()
camera_manager.start()

STATUS_HISTORY = collections.deque(maxlen=50)

def _record_status(new_status):
    """Görünen durum (operatörün/robotun gördüğü) değiştiğinde geçmişe ve
    'ne zamandır bu durumda' zaman damgasına yazar. Aynı durum tekrar
    geldiğinde (her karede) tekrar tekrar yazmaz."""
    if new_status != system_state["status"]:
        system_state["status_since"] = time.time()
        STATUS_HISTORY.append({"timestamp": time.time(), "status": new_status})
        logger.info(f"DURUM: {new_status}")
    system_state["status"] = new_status

@app.after_request
def add_header(r):
    r.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    r.headers["Pragma"] = "no-cache"
    r.headers["Expires"] = "0"
    return r

def draw_info(frame, qr_list):
    for qr in qr_list:
        pts = qr['points'].reshape((-1, 1, 2))
        cv2.polylines(frame, [pts], isClosed=True, color=(255, 0, 0), thickness=3)

def gen_frames():
    while True:
        system_state["camera_connected"] = camera_manager.is_connected

        # Sistem durdurulmuşsa kamerayı serbest bırak ve siyah ekran göster
        if not current_config.IS_ACTIVE:
            black_frame = np.zeros((480, 640, 3), dtype=np.uint8)
            black_frame[:] = (20, 15, 10)
            ret, buffer = cv2.imencode('.jpg', black_frame)
            _record_status("DURDURULDU")
            system_state["qr_count"] = 0
            yield (b'--frame\r\n' b'Content-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')
            time.sleep(0.5)
            continue

        success, frame_ref = camera_manager.read()
        if not success or frame_ref is None:
            time.sleep(0.1)
            continue

        # Arka plan thread'i ile çakışmamak için karenin bir kopyasını alıyoruz
        frame = frame_ref.copy()

        qr_list = scanner.detect_and_decode(frame)
        _record_status(analyzer.analyze(qr_list))
        system_state["qr_count"] = len(qr_list)
        system_state["last_update"] = time.time()

        draw_info(frame, qr_list)
        
        # Kamera yayını üzerine durumu yazdır
        status_text = system_state["status"]
        if status_text.startswith("KAPALI"):
            color = (0, 255, 0) # Green (BGR)
        elif status_text.startswith("ACIK"):
            color = (0, 0, 255) # Red
        elif status_text.startswith("OTOMASYON UYUSMUYOR"):
            color = (0, 165, 255) # Orange (BGR)
        else:
            color = (150, 150, 150) # Gray
            
        (tw, th), _ = cv2.getTextSize(status_text, cv2.FONT_HERSHEY_SIMPLEX, 0.8, 2)
        cv2.putText(frame, status_text, (frame.shape[1] - tw - 20, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)
        
        ret, buffer = cv2.imencode('.jpg', frame)
        yield (b'--frame\r\n' b'Content-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')

@app.route('/')
def index():
    return render_template('maincontent.html')

@app.route('/otomasyon')
def otomasyon():
    return render_template('otomasyonEkrani.html')

@app.route('/video_feed')
def video_feed():
    return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/api/state')
def get_state():
    status = system_state["status"]
    if status.startswith("KAPALI"):
        is_open = False
    elif status.startswith("ACIK"):
        is_open = True
    else:
        is_open = None  # REFERANS YOK / OTOMASYON UYUSMUYOR / DURDURULDU / BILINMIYOR gibi belirsiz durumlar
    return jsonify({**system_state, "is_open": is_open})

@app.route('/api/camera/reconnect', methods=['POST'])
def camera_reconnect():
    """Arka plan thread'i zaten otomatik yeniden bağlanmayı dener; bu, operatörün
    fiziksel bir müdahaleden (kabloyu yeniden takma vb.) sonra yeniden açılışı
    elle tetiklemesi içindir."""
    camera_manager.release()
    return jsonify({"success": True})

@app.route('/api/history')
def get_history():
    return jsonify(list(STATUS_HISTORY)[::-1])

# --- CRUD ENDPOINTS FOR AUTOMATIONS ---

@app.route('/api/automations', methods=['GET'])
def get_automations():
    return jsonify(automations_db)

@app.route('/api/automations', methods=['POST'])
def add_automation():
    data = request.json
    new_id = "oto_" + str(uuid.uuid4())[:8]
    automations_db[new_id] = {
        "name": data.get("name", "İsimsiz Otomasyon"),
        "kapi_tipi": data.get("kapi_tipi", "Sürgülü Kapak"),
        "robot_mesafesi_m": float(data.get("robot_mesafesi_m", 1.0)),
        "mesafe_toleransi": float(data.get("mesafe_toleransi", 0.05)),
        "referans_alindi": False,
        "qr_cifti": None
    }
    save_db(automations_db)
    return jsonify({"success": True, "id": new_id, "data": automations_db[new_id]})

@app.route('/api/automations/<auto_id>', methods=['GET', 'PUT', 'DELETE'])
def manage_automation(auto_id):
    if auto_id not in automations_db:
        return jsonify({"error": "Not found"}), 404

    if request.method == 'GET':
        return jsonify(automations_db[auto_id])
        
    if request.method == 'DELETE':
        del automations_db[auto_id]
        save_db(automations_db)
        if current_config.ACTIVE_AUTO_ID == auto_id:
            current_config.ACTIVE_AUTO_ID = None
            system_state["automation_id"] = "Seçilmedi"
        return jsonify({"success": True})
        
    data = request.json
    db_item = automations_db[auto_id]

    if "kapi_tipi" in data:
        db_item["kapi_tipi"] = data["kapi_tipi"]
    if "robot_mesafesi_m" in data:
        db_item["robot_mesafesi_m"] = float(data["robot_mesafesi_m"])
    if "mesafe_toleransi" in data:
        db_item["mesafe_toleransi"] = float(data["mesafe_toleransi"])

    save_db(automations_db)

    # If the updated automation is currently active, apply changes immediately
    if current_config.ACTIVE_AUTO_ID == auto_id:
        current_config.DISTANCE_TOLERANCE = db_item["mesafe_toleransi"]

    return jsonify({"success": True})



@app.route('/api/config', methods=['GET', 'POST'])
def handle_config():
    if request.method == 'POST':
        data = request.json
        if 'DISTANCE_TOLERANCE' in data: current_config.DISTANCE_TOLERANCE = float(data['DISTANCE_TOLERANCE'])
        if 'IS_ACTIVE' in data: current_config.IS_ACTIVE = bool(data['IS_ACTIVE'])
        return jsonify({"message": "Config updated", "IS_ACTIVE": current_config.IS_ACTIVE})

    return jsonify({
        "DISTANCE_TOLERANCE": current_config.DISTANCE_TOLERANCE,
        "IS_ACTIVE": getattr(current_config, 'IS_ACTIVE', True),
        "ACTIVE_AUTO_ID": current_config.ACTIVE_AUTO_ID,
        "OPEN_ALERT_SECONDS": current_config.OPEN_ALERT_SECONDS
    })

@app.route('/api/set_target', methods=['POST'])
def set_target():
    data = request.json
    auto_id = data.get('id')

    if auto_id not in automations_db:
        # Dahili ID bilinmiyorsa (örn. robot yalnızca otomasyon adını biliyorsa) isimle ara
        name = data.get('name')
        auto_id = next((aid for aid, a in automations_db.items() if a["name"] == name), None)

    if auto_id in automations_db:
        auto_data = automations_db[auto_id]
        current_config.ACTIVE_AUTO_ID = auto_id
        current_config.DISTANCE_TOLERANCE = auto_data["mesafe_toleransi"]
        system_state["automation_id"] = auto_data["name"]
        system_state["cabinet_type"] = auto_data["kapi_tipi"]
        return jsonify({"success": True, "id": auto_id, "data": auto_data})
    return jsonify({"success": False, "error": "Otomasyon bulunamadi (id veya name eslesmedi)"}), 404

@app.route('/api/capture_reference', methods=['POST'])
def capture_reference():
    """Operatör 'Referans Al (Kapalı)' butonuna bastığında çağrılır.
    Otomatik/gizli öğrenme yoktur - kapının 'kapalı hali', operatör kapıyı
    fiilen kapalı görürken bu endpoint'i tetiklediği an, sonraki 20 karenin
    ortalaması alınarak kaydedilir. Sadece geometri kaydedilir, tolerans
    hesaplanmaz; toleranslar ayrıca /api/config ile canlı ayarlanır."""
    analyzer.start_reference_capture()
    return jsonify({"success": True, "message": "Referans yakalama basladi (20 kare bekleniyor)."})

@app.route('/api/cancel_reference', methods=['POST'])
def cancel_reference():
    analyzer.cancel_reference_capture()
    return jsonify({"success": True})

@app.route('/api/reset_baselines', methods=['POST'])
def reset_baselines():
    """Öğrenme hafızasını (baselines.json) sıfırlar.
    Sistem tüm kabinleri unutur ve sıfırdan öğrenmeye başlar."""
    analyzer.baselines = {}
    analyzer.cancel_reference_capture()
    try:
        with open(analyzer.baselines_file, 'w') as f:
            json.dump({}, f)
        analyzer.history.clear()
        for auto in automations_db.values():
            auto["referans_alindi"] = False
            auto["qr_cifti"] = None
        save_db(automations_db)
        logger.info("BASELINES SIFIRLANDI - Sistem sifirdan ogrenecek.")
        return jsonify({"success": True, "message": "Ogrenme hafizasi sifirlandi."})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False, threaded=True)
